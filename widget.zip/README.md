# amoCRM-simplest-adder

This is a small, as easy to understand as possible => private integration (JS widget) which sums up the values of two fields, s1 and s2 and writes the result in the summa field. Working even without clicking the save button in the Transaction card

___

Это маленькая, максимально лёгкая в понимании => приватная интеграция (JS-виджет) который суммирует значения двух полей, s1 и s2 и записывает результат в поле summa. Работая даже без нажатия кнопки сохранить в карточке Сделки  

### __Как билдить?__

Просто закинуть эти файлы и папки _manifest.json_ _script.js_ _images_ _i18_ в архив и назвать его __widget.zip__  
Всё, этот архив залить в систему, во вкладке amoMarket

### __Как пользоваться?__

![Установка](/просто%20для%20понимания/img1.png)
Перед или после устарновки вписать idшники полей в эти инпуты и нажмать кнопку сохранить

![Пример](/просто%20для%20понимания/image.png)
Вот работа данных полей