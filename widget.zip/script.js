define(['./App.js?v='+Math.random()], function (CustomWidget) {
    return CustomWidget;
});
